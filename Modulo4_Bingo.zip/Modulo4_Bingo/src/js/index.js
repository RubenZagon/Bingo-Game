
const btnLanzar = document.querySelector('.btnThrow');

/*
La función que creará los cartones.
    -  Devuelve un array con números al azar (1-90)
    - Selecciona los 15 primeros números del array y nos quedamos con ellos.
    - Verificamos que no se deban repetir
*/

const createCard = function () {
    let rango = _.range(1, 91);
    let desordenado = _.shuffle(rango);
    console.log(desordenado);
    return desordenado;
}

btnLanzar.addEventListener('click', createCard)